// Auto-generated at build time.
// Netlify: set env var API_BASE to your backend URL (e.g. https://isdapresyo-backend.onrender.com)
// Local dev: always use same-origin (so localhost uses the local backend).
(function () {
	const isLocal = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
	if (isLocal) {
		window.API_BASE = '';
		return;
	}

	window.API_BASE = "https://example.onrender.com";
})();
